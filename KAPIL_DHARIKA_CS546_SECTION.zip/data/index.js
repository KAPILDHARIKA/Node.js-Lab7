const postData = require("./posts");
const animalsData = require("./animals");
const likesData = require("./likes");

module.exports = {
    posts: postData,
    animals: animalsData,
    likes: likesData
};